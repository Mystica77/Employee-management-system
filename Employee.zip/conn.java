package employee.management.system;


import com.mysql.cj.jdbc.Driver;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;

import static java.lang.Class.forName;

public class conn {

    Connection connection;
    Statement statement;
    public conn(){
        try{
            Class.forName("com.mysql.cj.jdbc.Driver");
            connection= DriverManager.getConnection("jdbc:mysql://localhost:3306/employeemanagementsystem","root","milipatra");
            statement = connection.createStatement();


        }catch(Exception e){
            e.printStackTrace();
        }
    }

}
